#include "types.h"
#include "user.h"
#include "stat.h"

int
main(int argc, char *argv[]){
	procdump();
	exit();
	return 0;
}
